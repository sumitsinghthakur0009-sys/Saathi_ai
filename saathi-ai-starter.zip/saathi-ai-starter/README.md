# Saathi AI — editable starter v0.1

A responsive, beginner-friendly multilingual companion chat prototype. The UI is plain HTML, CSS and JavaScript so it is straightforward to edit in SPCK Editor on Android.

## What works immediately

- Responsive chat layout, dark/light theme toggle, profile settings, and persona selector.
- 20 language choices. Demo mode has limited fallback replies; a connected AI provider is needed for fluent responses across languages.
- Vibe selector (supportive, playful, dark-ish humour, reflective, language tutor, romantic/flirty).
- Local chat history saved to this browser with `localStorage`.
- Quick joke button, starter prompts, and Google web-search launch using the text box.
- Image file picker and attachment label for screenshots. **Images are local-preview placeholders only; they are not sent to the AI in this version.**
- Optional server integration using OpenAI's Responses API. The API key stays on the server in `.env`.

## Run the front-end only

1. Open `public/index.html` in SPCK Editor.
2. Preview it in SPCK. If opened as a local file, chat works in **Demo mode**. Demo mode is not a real AI model.
3. Edit styling in the `<style>` section and UI behaviours in the `<script>` section. Search for `const jokes`, `localReply`, and the `persona` `<select>` to customise common items.

## Connect real AI (requires a Node.js host)

The browser alone cannot safely keep a provider API key. The server is optional and is intended to run on a supported Node.js host (or a computer with Node.js installed); SPCK on its own is a front-end editor, not a Node.js hosting service.

1. Install Node.js 20 or newer on a computer/server.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env` and put your private API key in `OPENAI_API_KEY`. Set `OPENAI_MODEL` to a model available to your API account.
4. Run `npm start` and open `http://localhost:3000`.
5. Check `http://localhost:3000/api/health`. It should return `aiConfigured: true` when configured.

API usage may incur charges. Set usage limits/alerts with your provider and never commit `.env` to GitHub. API keys must not be put into browser JavaScript. See the OpenAI API key safety guidance: https://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety

## Important limitations / next steps

- This is a starter, not a guaranteed bug-free production app. Test on your actual phone and host before publishing.
- The server has basic request-size and rate limiting, but production would still need authentication, stronger abuse controls, monitoring, and a privacy policy.
- Interface labels are primarily English; the **AI reply language** is selected from 20 options. For a fully translated interface, create a translation dictionary for every label.
- Web search opens Google in a new tab. The AI does not automatically search the web in this version.
- Browser chat history is not encrypted and can be seen by someone who uses the same browser profile. Do not store sensitive or highly personal details.
- Image attachment is local preview only. Multimodal image understanding needs a separate, carefully bounded server feature.
- Romantic/flirty mode is designed to stay non-graphic and is disabled for family and authority-role personas. Keep fictional characters adults and conversations consensual.

## Project structure

```text
saathi-ai-starter/
├── public/
│   └── index.html    # UI + beginner-friendly frontend logic
├── server.js         # Optional secure AI proxy/backend
├── package.json
├── .env.example      # Template only; no real key
├── .gitignore
└── README.md
```
