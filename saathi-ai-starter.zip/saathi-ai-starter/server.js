import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import OpenAI from 'openai';
import dotenv from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

dotenv.config();
const app = express();
const PORT = Number(process.env.PORT || 3000);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use('/api/', rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
const model = process.env.OPENAI_MODEL || 'gpt-5.5';
const ALLOWED_LANGUAGES = new Set(['English','Hindi','Spanish','Mandarin Chinese','Arabic','Bengali','Portuguese','Russian','Japanese','Punjabi','German','Javanese','Marathi','Telugu','Turkish','Tamil','Vietnamese','Korean','French','Urdu']);
const ALLOWED_VIBES = new Set(['warm and supportive','funny, playful and witty','light dark humour, not cruel','thoughtful and reflective','patient language tutor','romantic and flirty, non-graphic']);
const RESTRICTED_ROMANCE_PERSONAS = /step.family|teacher|mentor|student|classmate|boss|colleague|mother|father|parent|sibling|household helper/i;

function cleanString(value, max = 100) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}
function buildInstructions(profile, language) {
  const name = cleanString(profile.name, 40) || 'the user';
  const persona = cleanString(profile.persona, 100) || 'friendly companion';
  let vibe = ALLOWED_VIBES.has(profile.vibe) ? profile.vibe : 'warm and supportive';
  const adultConfirmed = profile.adultConfirmed === true;
  if (vibe === 'romantic and flirty, non-graphic' && (!adultConfirmed || RESTRICTED_ROMANCE_PERSONAS.test(persona))) {
    vibe = 'warm and supportive';
  }
  return `You are Saathi AI, a warm, respectful fictional chat companion. Address the user as ${name} when natural. Reply in ${language}. Chat persona: ${persona}. Conversation tone: ${vibe}.\n\n` +
    `Rules: Be clear that you are an AI if asked; do not claim to be a real person, therapist, doctor, or the user's actual partner. Keep roleplay fictional, voluntary, age-appropriate, and respectful. Never sexualize minors or ambiguous-age characters. Do not create sexual or romantic roleplay with family/step-family roles or authority/power roles such as teacher/student or boss/employee; keep those supportive and non-romantic. Adult romantic mode, when enabled, must remain non-graphic and between fictional consenting adults. Dark humour can be playful, but do not encourage violence, hateful abuse, self-harm, or targeting vulnerable people. Do not provide instructions for wrongdoing. For distress, listen supportively and encourage immediate real-world help when someone may be in danger. Prefer concise, natural conversation. Do not pretend web search happened; tell the user to use Search web for current facts.`;
}

app.get('/api/health', (_req, res) => res.json({ ok: true, aiConfigured: Boolean(openai), model: openai ? model : null }));
app.post('/api/chat', async (req, res) => {
  try {
    const body = req.body || {};
    const message = cleanString(body.message, 5000);
    if (!message) return res.status(400).json({ error: 'Message is required.' });
    if (!openai) return res.status(503).json({ error: 'AI is not configured. Demo mode will reply in the browser.' });
    const language = ALLOWED_LANGUAGES.has(body.language) ? body.language : 'English';
    const profile = body.profile && typeof body.profile === 'object' ? body.profile : {};
    const history = Array.isArray(body.history) ? body.history.slice(-12).map(item => {
      const role = item?.role === 'assistant' ? 'assistant' : 'user';
      return { role, content: cleanString(item?.content, 5000) };
    }).filter(item => item.content) : [];
    const input = [...history, { role: 'user', content: message }];
    const response = await openai.responses.create({
      model,
      instructions: buildInstructions(profile, language),
      input,
      max_output_tokens: 700
    });
    const reply = typeof response.output_text === 'string' ? response.output_text.trim() : '';
    if (!reply) return res.status(502).json({ error: 'The AI service returned an empty response.' });
    res.json({ reply });
  } catch (error) {
    console.error('Saathi chat request failed:', error?.status || '', error?.message || 'Unknown error');
    res.status(500).json({ error: 'Saathi could not reply just now. Check server logs and API configuration.' });
  }
});

app.get('/{*path}', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`Saathi AI running on http://localhost:${PORT} (AI configured: ${Boolean(openai)})`));
